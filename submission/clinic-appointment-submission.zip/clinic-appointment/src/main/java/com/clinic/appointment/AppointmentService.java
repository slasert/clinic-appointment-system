package com.clinic.appointment;

import com.clinic.exception.SchedulingException;
import com.clinic.exception.ValidationException;
import com.clinic.model.Doctor;
import com.clinic.model.Patient;
import com.clinic.model.Requester;
import com.clinic.rules.BusinessRule;
import com.clinic.rules.ClinicRules;

import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/**
 * Central service that books, cancels and reschedules appointments while
 * enforcing the clinic rules defined in {@link ClinicRules}.
 *
 * <p>The current time is taken from an injected {@link Clock} so that every
 * time-dependent rule can be tested deterministically.</p>
 */
public class AppointmentService {

    private final Clock clock;
    private final Map<String, Patient> patients = new LinkedHashMap<>();
    private final Map<String, Doctor> doctors = new LinkedHashMap<>();
    private final Map<String, Appointment> appointments = new LinkedHashMap<>();
    private int nextAppointmentNumber = 1;

    public AppointmentService(Clock clock) {
        this.clock = Objects.requireNonNull(clock, "clock");
    }

    // ---------------------------------------------------------------- registration

    public void registerPatient(Patient patient) {
        if (patient == null) {
            throw new ValidationException(BusinessRule.REQUIRED_INPUT, "Patient cannot be null");
        }
        if (patients.containsKey(patient.getId())) {
            throw new ValidationException(BusinessRule.UNIQUE_ID, "Patient " + patient.getId() + " is already registered");
        }
        patients.put(patient.getId(), patient);
    }

    public void registerDoctor(Doctor doctor) {
        if (doctor == null) {
            throw new ValidationException(BusinessRule.REQUIRED_INPUT, "Doctor cannot be null");
        }
        if (doctors.containsKey(doctor.getId())) {
            throw new ValidationException(BusinessRule.UNIQUE_ID, "Doctor " + doctor.getId() + " is already registered");
        }
        doctors.put(doctor.getId(), doctor);
    }

    // ---------------------------------------------------------------- booking

    /**
     * Books a 30-minute appointment.
     *
     * @throws ValidationException  unknown patient/doctor or malformed start time
     * @throws SchedulingException  a clinic rule prevents the booking
     */
    public Appointment book(String patientId, String doctorId, LocalDateTime start) {
        Patient patient = findPatient(patientId);
        Doctor doctor = findDoctor(doctorId);
        TimeSlotPolicy.validate(start, now());
        checkAvailability(patient, doctor, start, null);

        Appointment appointment = new Appointment(nextId(), patient, doctor, start);
        appointments.put(appointment.getId(), appointment);
        return appointment;
    }

    /**
     * Cancels an appointment according to the cancellation policy:
     * <ul>
     *   <li>at least 24 hours before the start: anyone may cancel</li>
     *   <li>less than 24 hours before: only staff, recorded as a late cancellation</li>
     *   <li>after the start time: not allowed</li>
     * </ul>
     */
    public void cancel(String appointmentId, Requester requester) {
        Appointment appointment = findAppointment(appointmentId);
        boolean late = checkChangePolicy(appointment, requester);
        appointment.cancel(late);
    }

    /**
     * Moves an appointment to a new slot as one atomic operation: either the old
     * appointment becomes RESCHEDULED and a new one is created, or nothing changes.
     */
    public Appointment reschedule(String appointmentId, LocalDateTime newStart, Requester requester) {
        Appointment original = findAppointment(appointmentId);
        checkChangePolicy(original, requester);
        TimeSlotPolicy.validate(newStart, now());
        if (newStart.equals(original.getStart())) {
            throw new SchedulingException(BusinessRule.SAME_TIME_RESCHEDULE, "New time is the same as the current appointment time");
        }
        checkAvailability(original.getPatient(), original.getDoctor(), newStart, original);

        Appointment moved = new Appointment(nextId(), original.getPatient(), original.getDoctor(), newStart);
        original.markRescheduled();
        appointments.put(moved.getId(), moved);
        return moved;
    }

    /** Marks a scheduled appointment as completed. Allowed once the appointment has started. */
    public void complete(String appointmentId) {
        Appointment appointment = findAppointment(appointmentId);
        requireScheduled(appointment);
        if (now().isBefore(appointment.getStart())) {
            throw new SchedulingException(BusinessRule.COMPLETION_TIME, "Appointment cannot be completed before it starts");
        }
        appointment.complete();
    }

    /** Marks a scheduled appointment as no-show. Allowed once the appointment slot has ended. */
    public void markNoShow(String appointmentId) {
        Appointment appointment = findAppointment(appointmentId);
        requireScheduled(appointment);
        if (now().isBefore(appointment.getEnd())) {
            throw new SchedulingException(BusinessRule.NO_SHOW_TIME, "Appointment cannot be marked as no-show before its slot ends");
        }
        appointment.markNoShow();
    }

    /**
     * Adds a staff note to an appointment (any status). Notes are 1..200 characters
     * after trimming, at most 5 per appointment.
     */
    public void addNote(String appointmentId, String note) {
        Appointment appointment = findAppointment(appointmentId);
        if (note == null || note.isBlank()) {
            throw new ValidationException(BusinessRule.NOTE_LENGTH, "Note cannot be empty");
        }
        String trimmed = note.trim();
        if (trimmed.length() > ClinicRules.MAX_NOTE_LENGTH) {
            throw new ValidationException(BusinessRule.NOTE_LENGTH, "Note cannot be longer than " + ClinicRules.MAX_NOTE_LENGTH + " characters");
        }
        if (appointment.getNotes().size() >= ClinicRules.MAX_NOTES_PER_APPOINTMENT) {
            throw new SchedulingException(BusinessRule.NOTE_LIMIT, "An appointment can have at most "
                    + ClinicRules.MAX_NOTES_PER_APPOINTMENT + " notes");
        }
        appointment.addNote(trimmed);
    }

    // ---------------------------------------------------------------- queries

    public Appointment findAppointment(String appointmentId) {
        Appointment appointment = appointmentId == null ? null : appointments.get(appointmentId);
        if (appointment == null) {
            throw new ValidationException(BusinessRule.KNOWN_REFERENCE, "Unknown appointment: " + appointmentId);
        }
        return appointment;
    }

    /** Scheduled appointments of a doctor on the given date, ordered by time. */
    public List<Appointment> getDoctorSchedule(String doctorId, LocalDate date) {
        Doctor doctor = findDoctor(doctorId);
        if (date == null) {
            throw new ValidationException(BusinessRule.REQUIRED_INPUT, "Date cannot be null");
        }
        return appointments.values().stream()
                .filter(a -> a.getDoctor().equals(doctor))
                .filter(a -> a.getDate().equals(date))
                .filter(a -> a.getStatus() == AppointmentStatus.SCHEDULED)
                .sorted(Comparator.comparing(Appointment::getStart))
                .toList();
    }

    /** All appointments of a patient (any status), ordered by time. */
    public List<Appointment> getPatientAppointments(String patientId) {
        Patient patient = findPatient(patientId);
        return appointments.values().stream()
                .filter(a -> a.getPatient().equals(patient))
                .sorted(Comparator.comparing(Appointment::getStart))
                .toList();
    }

    /** Start times on the given date that a doctor could still accept a booking for. */
    public List<LocalDateTime> getAvailableSlots(String doctorId, LocalDate date) {
        Doctor doctor = findDoctor(doctorId);
        if (date == null) {
            throw new ValidationException(BusinessRule.REQUIRED_INPUT, "Date cannot be null");
        }
        List<LocalDateTime> free = new ArrayList<>();
        if (countDoctorAppointments(doctor, date, null) >= doctor.getDailyLimit()) {
            return free;
        }
        LocalDateTime now = now();
        for (LocalDateTime start : TimeSlotPolicy.dailySlots(date)) {
            if (TimeSlotPolicy.findViolation(start, now).isEmpty() && !isDoctorBusy(doctor, start, null)) {
                free.add(start);
            }
        }
        return free;
    }

    // ---------------------------------------------------------------- rules

    /**
     * Checks conflicts and limits. {@code ignored} is the appointment being
     * rescheduled, which must not count against itself.
     */
    private void checkAvailability(Patient patient, Doctor doctor, LocalDateTime start, Appointment ignored) {
        if (isDoctorBusy(doctor, start, ignored)) {
            throw new SchedulingException(BusinessRule.DOCTOR_CONFLICT, doctor + " already has an appointment at " + start);
        }
        boolean patientBusy = appointments.values().stream()
                .filter(a -> a != ignored)
                .anyMatch(a -> a.getStatus() == AppointmentStatus.SCHEDULED
                        && a.getPatient().equals(patient)
                        && a.getStart().equals(start));
        if (patientBusy) {
            throw new SchedulingException(BusinessRule.PATIENT_CONFLICT, patient + " already has an appointment at " + start);
        }
        if (countDoctorAppointments(doctor, start.toLocalDate(), ignored) >= doctor.getDailyLimit()) {
            throw new SchedulingException(BusinessRule.DOCTOR_DAILY_LIMIT, doctor + " has reached the daily limit of "
                    + doctor.getDailyLimit() + " appointments");
        }
        // Only upcoming appointments are active; past ones left in SCHEDULED must not block the patient (DEF-01).
        LocalDateTime now = now();
        long active = appointments.values().stream()
                .filter(a -> a != ignored)
                .filter(a -> a.getStatus() == AppointmentStatus.SCHEDULED && a.getPatient().equals(patient))
                .filter(a -> a.getEnd().isAfter(now))
                .count();
        if (active >= ClinicRules.MAX_ACTIVE_APPOINTMENTS_PER_PATIENT) {
            throw new SchedulingException(BusinessRule.PATIENT_ACTIVE_LIMIT, patient + " already has "
                    + ClinicRules.MAX_ACTIVE_APPOINTMENTS_PER_PATIENT + " active appointments");
        }
    }

    private boolean isDoctorBusy(Doctor doctor, LocalDateTime start, Appointment ignored) {
        return appointments.values().stream()
                .filter(a -> a != ignored)
                .anyMatch(a -> a.getStatus() == AppointmentStatus.SCHEDULED
                        && a.getDoctor().equals(doctor)
                        && a.getStart().equals(start));
    }

    private long countDoctorAppointments(Doctor doctor, LocalDate date, Appointment ignored) {
        return appointments.values().stream()
                .filter(a -> a != ignored)
                .filter(a -> a.getStatus().occupiesSlot())
                .filter(a -> a.getDoctor().equals(doctor) && a.getDate().equals(date))
                .count();
    }

    /**
     * Applies the cancellation/reschedule policy decision table.
     *
     * @return true if the change is a late change (less than 24 hours before the start)
     */
    private boolean checkChangePolicy(Appointment appointment, Requester requester) {
        if (requester == null) {
            throw new ValidationException(BusinessRule.REQUIRED_INPUT, "Requester cannot be null");
        }
        requireScheduled(appointment);
        LocalDateTime now = now();
        if (!now.isBefore(appointment.getStart())) {
            throw new SchedulingException(BusinessRule.ALREADY_STARTED, "Appointment has already started");
        }
        boolean late = now.plusHours(ClinicRules.FREE_CANCELLATION_HOURS).isAfter(appointment.getStart());
        if (late && requester == Requester.PATIENT) {
            throw new SchedulingException(BusinessRule.LATE_CHANGE, "Patients cannot change an appointment less than "
                    + ClinicRules.FREE_CANCELLATION_HOURS + " hours before it starts; please contact the clinic");
        }
        return late;
    }

    private void requireScheduled(Appointment appointment) {
        if (appointment.getStatus() != AppointmentStatus.SCHEDULED) {
            throw new SchedulingException(BusinessRule.STATUS_FINAL, "Appointment " + appointment.getId()
                    + " is " + appointment.getStatus() + " and cannot be changed");
        }
    }

    private Patient findPatient(String patientId) {
        Patient patient = patientId == null ? null : patients.get(patientId);
        if (patient == null) {
            throw new ValidationException(BusinessRule.KNOWN_REFERENCE, "Unknown patient: " + patientId);
        }
        return patient;
    }

    private Doctor findDoctor(String doctorId) {
        Doctor doctor = doctorId == null ? null : doctors.get(doctorId);
        if (doctor == null) {
            throw new ValidationException(BusinessRule.KNOWN_REFERENCE, "Unknown doctor: " + doctorId);
        }
        return doctor;
    }

    private LocalDateTime now() {
        return LocalDateTime.now(clock);
    }

    private String nextId() {
        // Locale.ROOT keeps ASCII digits on every machine (DEF-02).
        return String.format(Locale.ROOT, "A%04d", nextAppointmentNumber++);
    }
}
